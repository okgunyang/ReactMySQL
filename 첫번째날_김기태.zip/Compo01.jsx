//const 컴포넌트이름 = () => { }
const Compo01 = () => {
    //리턴되는 내용은 하나로 묶어서 처리
    return(
        <div>
            <h2>첫 번째 컴포넌트</h2>
        </div>
    )
}
//export default 컴포넌트이름
export default Compo01;