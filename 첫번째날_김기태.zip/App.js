import './App.css'
import RouterPage from './components/RouterPage'

function App() {
  return (
    <div className="App">
      <h1>리액트 라우터 시작</h1>
      <RouterPage />
      <hr />
    </div>
  );
}

export default App
