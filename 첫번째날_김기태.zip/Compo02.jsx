//rafce 단축 명령
import React from 'react'

const Compo02 = () => {
  return (
    <div>
        <h2>두 번째 컴포넌트</h2>
    </div>
  )
}

export default Compo02