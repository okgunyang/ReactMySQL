import './App.css';
import Homepage from './components/Homepage';
import RouterPage from './components/RouterPage';

function App() {
  return (
    <div className="App">
      <RouterPage />
    </div>
  );
}

export default App;
