import React from 'react'

const Homepage = () => {
  return (
    <div className="my-5">
        <h1 className='text-center'>Homepage</h1>
    </div>
  )
}

export default Homepage